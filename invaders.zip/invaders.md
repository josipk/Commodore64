﻿
INVADERS
=======

Written by Josip Retro Bits for the BASIC 10Liner Contest 2023.

Language: Commodore 64 Basic v2

Category: PUR-80


The story
----
Invasion on our planet has begun and with your ship, you find yourself on the front line facing the enemies.
It is important to kill as many enemies as you can and help your comrades behind you.

Controls and play
--------

Press key '1' to change the moving direction to the left, and key '9' to change the moving direction to the right.
Press key '8' to shoot. Kill as many enemies until you run out of time.

Loading
-------

You can use any Commodore 64 emulator that works with *.d64 files, commonly used is VICE.

- In VICE:
	- Click: File -> Attach disk image -> Unit #8
	- Select: invaders.d64
	- Click: Open or Attach or Autostart (depends on the VICE and OS versions)


Another option is just to drag invaders.d64 file and drop in VICE.

If the game does not start automatically then type

	LOAD"INVADERS",8
	RUN
 
On the real hardware, just load with:

	LOAD"INVADERS",8
	RUN


Code description
----------------

Moving enemies is done by calling kernel routine (59749) which is used to inject empty line during typing in commands from the keyboard
(because a single line of code takes two lines on the screen). This routine moves down all lines below an injected line.
With a little hack, it is possible to use this and produce a constant scrolling-down effect.

Line by line code overview
----------------


- Line 0:
	- Clear the screen and initialise variables used in the game
- Line 1:
	- Initialise kernel scroll-down routine
	- Print "Score" on the screen
	- Initialise some additional variables
- Line 2:
	- Create a new enemy at a random x position in the third line on the screen.
	- Delete the shot on the screen
- Line 3:
	- Call kernel routine to scroll down the screen
	- Recreate ship on his current position on the screen
	- Recreate a shot on his current position on the screen
- Line 4:
	- Check if the shot hit an enemy, if so then jump to line 7
	- Increment the timer
	- Check if the enemy hit the ship, if so print "game over" and end the game
- Line 5:
	- Read the keyboard
	- Set the direction of the ship according to keys '1' and '9'
	- Change ship direction if it hits the borders of the screen
- Line 6:
	- Check if the player pressed '8' to fire a shot or if shooting is in progress.
	- If there is no shot fired then jump to line 9
	- Else delete the old shot position on the screen.
- Line 7:
	- Display the new shot position on the screen
	- If a shot hit an enemy then delete that enemy 
	- Delete the shot and cancel the shooting process
	- Print a new score on the screen
- Line 8:
	- If the shot reached the top of the screen then delete it 
	- Cancel the shooting process
- Line 9:
	- Increment position of the ship
	- Clear the old ship position and display it on the new position
	- If the timer did not reach the end then jump to line 2
	- Else print "time out" and end the game


