﻿
CAVE ESCAPE
=======

Written by Josip Retro Bits for the BASIC 10Liner Contest 2023.

Language: Commodore 64 Basic v2

Category: PUR-80


The story
----
Your ship is trapped inside a large cave on an unknown planet.
You need to escape from the cave while the alien ship is blocking your way. 
There is not much time left until the bomb that you set up goes off!

Controls and play
--------

Press any key to move your ship forward. Keep eye on the alien ship, he is making it harder to progress forward.
If you pass him, he will follow you and move in front of you.
Reach the end of the cave before you run out of time.
p.s. The game has a cheat that can help you with the time limitation :)


Loading
-------

You can use any Commodore 64 emulator that works with *.d64 files, commonly used is VICE.

- In VICE:
	- Click: File -> Attach disk image -> Unit #8
	- Select: cave_escape.d64
	- Click: Open or Attach or Autostart (depends on the VICE and OS versions)


Another option is just to drag cave_escape.d64 file and drop in VICE.

If the game does not start automatically then type

	LOAD"CAVE",8
	RUN
 
On the real hardware, just load with:

	LOAD"CAVE",8
	RUN


Line by line code overview
----------------

- Line 0:
	- Set the text colour to white and clear the screen 
	- Initialisation of variables used in the game
- Line 1:
	- Setting screen and border colours
	- Drawing the cave
- Line 2:
	- Display a player on the screen
	- Initialise additional variables
	- Jumping to line 4
- Line 3:
	- Move the enemy ship for two steps forward (2 columns)
	- Reduce the distance that enemy ship travels vertically every 4 columns
- Line 4:
	- Recalculate the enemy's new position when vertical distance is reduced
	- Check if the enemy crosses the end of the screen (passes the last column), if so the game ends
- Line 5:
	- Calculate the enemy's new vertical position
	- Display the enemy in the new position, clear the old position
	- Check if the enemy hit the player ship, if so jump to line 9
- Line 6:
	- Switch enemy direction when it hits cave borders
	- Read the keyboard
	- If the key is not pressed jump to line 8
	- If the key is pressed then increment player position by 1. (move forward)
- Line 7:
	- Display the player ship new position on the screen
	- Check if the player ship hit the enemy, if so jump to line 9
- Line 8:
	- Check if the player ship reached the end of the screen (last column), if so jump to line 9
	- If the player ship new position is bigger than the enemy position, jump to line 3
	- Increment timer and display on the screen
	- If we did not reach the time limit jump to line 4
	- Else continue to line 9
- Line 9:
	- Write the score on the screen (the number of steps the player managed to cross)
	- Write "game over"
	- If the player managed to reach the end of the cave, delete "over" and print "end"
	
	
Cheat
----------------
While the cave is drawn on the screen, you can press any key an even number of times.
This will fill the keyboard buffer and you will progress forward without hitting the enemy once the game begins.
This can save you a lot of time in the game :)

